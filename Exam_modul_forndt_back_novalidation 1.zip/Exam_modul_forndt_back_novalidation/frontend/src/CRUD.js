import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import Form from 'react-bootstrap/Form';
const CRUD =()=>{



    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const [exId,setExId] = useState("")
    const [examName,setExName] = useState("")
    const [examDate,setExDate] = useState("")
    const [className,setLExClName] = useState("")
    const [subjectName,setExSbName] = useState("")

    const [exEditId,setEditExId] = useState("")
    const [examEditName,setEditExname] = useState("")
    const [examEditDate,setEditExDate] = useState("")
    const [classEditName,setLEditExClname] = useState("")
    const [subjectEditName,setEditExSbname] = useState("")

    
  const [errors, setErrors] = useState({
    examNameError: "",
    examDateError: "",
    classNameError: "",
    subjectNameError: ""
  });

  const validateExamName = (name) => {
    if (!name) {
      setErrors((prevErrors) => ({ ...prevErrors, examNameError: "Exam name is required." }));
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, examNameError: "" }));
    }
  };


    const [options,setOption] = useState([]) 
    const [data,setdata] = useState([])

    useEffect(()=>{
        // setdata(stdData)
        axios.get('http://localhost:5247/api/Examination/GetExamination')
      .then((result)=>{
        setOption(result.data)
        console.log("Setoptions");
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
        getData()
    },[])


    const getData =()=>{
      axios.get('http://localhost:5247/api/Examination/GetExamination')
      .then((result)=>{
        setdata(result.data)
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }

    const handleEdit =(examId)=>{
       handleShow();
       axios.get(`http://localhost:5247/api/Examination/GetExamById/${examId}`)
       .then((result)=>{
        console.log(result.data);
        setEditExId(result.data.examId)
        setEditExname(result.data.examName)
        setEditExDate(result.data.examDate)
        setLEditExClname(result.data.clsName)
        setEditExSbname(result.data.subject)
       })
       .catch((error)=>{
        toast.error(error)
       })
    }

    const handleDelete =(examId)=>
    {
      if(window.confirm("Are you sure to delete this Exam") === true){
        axios.delete(`http://localhost:5247/api/Examination/Delete Exam/${examId}`)
        .then((result)=>{
          if(result.status === 200)
          {
            toast.success("Deleted succesfully")
            getData();
          }
          
        })
        .catch((error)=>{
          toast.error(error)
        })
      }
     
    }

    const handleUpdate = ()=>{
     console.log("check");
     const url ='http://localhost:5247/api/Examination/EditExam'
     const data = {
      examId: exEditId,
      examName: examEditName,
      examDate: examEditDate,
      classId: classEditName,
      subjectId: subjectEditName
    }
    

    console.log(data);
    
    axios.put(url,data)
    .then((result)=>{
      console.log("Entered into edit api");
      handleClose()
      
      getData();
      // clear();
      toast.success("Exam is  has been updated")
    })
    .catch((error)=>{
      console.log(error)
    })
    }
    //
    // const handleActiveChange =(e)=>{
    //   if(e.target.checked){
    //     setActive(1)
    //   }
    //   else{
    //     setActive(0)
    //   }
    // }
    //break
    // const handleEditActiveChange =(e)=>{
    //   if(e.target.checked){
    //     setEditActive(1)
    //   }
    //   else{
    //     setEditActive(0)
    //   }
    // }

    const handleSave = () =>{

      if(errors == null){
        
      const url ='http://localhost:5247/api/Examination/AddExam'
      const data = {
        examId: exId,
        examName: examName,
        examDate: examDate,
        classId: className,
        subjectId: subjectName
      }
      console.log(data);
      console.log("Entered");
      axios.post(url,data)
      .then((result)=>{
        console.log("Enterde");
        console.log(result.data);
        getData();
        clear();
        toast.success("Student has been added")
      })
      .catch((error)=>{
        toast.error(error)
      })
    }
    else{
      validateExamName();
    }
    
  }
    
    const clear = ()=>{
      setExId('')
      setExName('')
      setExDate('')
      setLExClName('')
      setExSbName('')
      setEditExId('')
      setEditExname('')
      setEditExDate('')
      setLEditExClname('')
      setEditExSbname('')
      
    }


    return(
        <Fragment>
          <ToastContainer/>
          <Container>
            <Row>
            <Col>
          <input type="text" className='form-control form-control-sm' placeholder='Enter ExamId '
           value={exId} onChange={(e)=> setExId(e.target.value)} />
        </Col>
            </Row>
      <Row className='pt-2'>
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Exam Name'
        value={examName}   onChange={(e) => {
          setExName(e.target.value);
          validateExamName(e.target.value);
        }}/>
        {errors.examNameError && <p className="error">{errors.examNameError}</p>}
        </Col>
        
      <Col>
        <input type="date" className='form-control form-control-sm' placeholder='Enter Date'
        value={examDate} onChange={(e)=> setExDate(e.target.value)} />
        </Col>
        <Col>
        <Form.Select
            aria-label="Select Class"
            name="className"
            value={className}
            onChange={(e)=> setLExClName(e.target.value)}
          >
            <option key="default" value="">
              Select Class
            </option>
            {options.map((option) => (
              <option key={option.classId} value={option.classId}>
                {option.clsName}
              </option>
            ))}
          </Form.Select>
        
        </Col>
        {/* <Form.Select aria-label="Default select example">
        <option>Select Class </option>
        {options.map((option)=>(
          <option key={option.clsName} value={option.clsName} onChange={(e)=> setLExClName(e.target.value)}>{options.className}</option>
        ))}
    </Form.Select> */}
        
        
        </Row>
        <Row className='pt-2'>
        <Col>
        <Form.Select
            aria-label="Select Subject"
            name="className"
            value={subjectName}
            onChange={(e)=> setExSbName(e.target.value)}
          >
            <option key="default" value="">
             Select Subject
            </option>
            {options.map((option) => (
              <option key={option.subjectId} value={option.subjectId}>
                {option.subject}
              </option>
            ))}
          </Form.Select>
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <button className='btn btn-primary  ' onClick={()=>handleSave()}>Add Exam</button>
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2'>
      <Table striped bordered hover>
      <thead>
        <tr>
          <th>index</th>
          <th>ExamId</th>
          <th>ExamName</th>
          <th>ExamDate</th>
          <th>ClassName</th>
          <th>SubjectName</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.examId}</td>
              <td>{item.examName}</td>
              <td>{item.examDate}</td>
              <td>{item.clsName}</td>
              <td>{item.subject}</td>
              <td colSpan={2}>
             
              
                <button className='btn btn-primary'  onClick={()=>handleEdit(item.examId)} >Edit</button> &nbsp;
                <button className='btn btn-danger' onClick={()=> handleDelete(item.examId)}  >Delete</button>
              </td>
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update Exam</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Exam Id'
        value={exEditId} onChange={(e)=> setEditExId(e.target.value)} />
        <input type="text" className='form-control' placeholder='Enter sub id '
        value={subjectEditName} onChange={(e)=> setEditExSbname(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter  Exam Name'
        value={examEditName} onChange={(e)=> setEditExname(e.target.value)} />
        </Col>
        <Col>
        <input type="date" className='form-control' placeholder='Enter Exam Date'
        value={examEditDate} onChange={(e)=> setEditExDate(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter classId'
        value={classEditName} onChange={(e)=> setLEditExClname(e.target.value)} />
        
        </Col>
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
        </Fragment>
    )
}

export default CRUD;


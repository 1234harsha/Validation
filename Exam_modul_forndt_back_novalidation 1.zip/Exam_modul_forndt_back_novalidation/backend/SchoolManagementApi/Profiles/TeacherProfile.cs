﻿using AutoMapper;
using SchoolManagementApi.DTO;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class TeacherProfile:Profile
    {
           
        public TeacherProfile()
        {
            CreateMap<Examinations, Examinationdto>();
            CreateMap<ExaminationAddDto, Examinations>();


        }
    }
}

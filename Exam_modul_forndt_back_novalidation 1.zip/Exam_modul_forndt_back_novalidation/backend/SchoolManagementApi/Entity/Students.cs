﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagementApi.Entity
{
    public class Students
    {
        [Key]
        public string StudentId { get; set; }
        [Required]
        public string RollNO { get; set; } = " ";
        [Required]
        public string FirstName { get; set; } = " ";
        [Required]
        public string LastName { get; set; } = " ";

        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = "abc@gmail.com";
        [Required]
        public DateTime DOB { get; set; } = new DateTime();
        [Required]
        public string Gender { get; set; } = " ";
        [Required]
        [Column("ClssId")]
        public string ClassId { get; set; }



        [ForeignKey("ClassId")]
        public Classes? Cls { get; set; }

    }
}

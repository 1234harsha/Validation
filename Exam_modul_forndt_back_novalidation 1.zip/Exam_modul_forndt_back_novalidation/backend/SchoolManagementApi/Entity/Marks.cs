﻿using SchoolManagementApi.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NexusProjectIntegration.Entity
{
    public class Marks
    {
        [Key]
        public string MarksId { get; set; }
        [Required]
        public string ExmId { get; set; }
        [Required]
        public string StuId { get; set; }
        [Required]
        public string ClssId { get; set;}
        [Required]
        public string SubId { get; set;}
        [Required]
        public int Mark { get; set; }
        [Required]
        public string Result { get; set; } = "Fail";
        [Required]
       


        [ForeignKey("StuId")]
        public Students ? Students { get; set; }
        [ForeignKey("ClssId")]
        public Classes ? Classes { get; set; }
        [ForeignKey("ExmId")]
        public Examinations ? Examinations { get; set; }

        [ForeignKey("SubId")]
        public Subject ? subjects { get; set; }
        

    }
}

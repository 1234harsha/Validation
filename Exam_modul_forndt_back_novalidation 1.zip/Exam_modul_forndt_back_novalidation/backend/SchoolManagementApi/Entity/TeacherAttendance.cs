﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.Entity
{
    public class TeacherAttendance
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string AttendanceId { get; set; }

        [Required]
        [Column("TeachId")]
        public string TeacherId { get; set; }

        [Required]

        public DateTime Date { get; set; }

        [Required]
        public string Status { get; set; }


        [ForeignKey("TeacherId")]
        public Teachers? teachers { get; set; }
    }
}

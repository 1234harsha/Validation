﻿using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public class ExaminationRepository : IExamination
    {
        private readonly MyContext _context;

        public ExaminationRepository(MyContext context)
        {
            _context = context; 
        }
        public void Add(Examinations examinations)
        {
            _context.Examinations.Add(examinations);
            _context.SaveChanges(); 
          
        }

        public void Delete(string eId)
        {
            Examinations exam = _context.Examinations.Find(eId);
            _context.Examinations.Remove(exam);
            _context.SaveChanges();
        }

        public List<Examinations> GetAll()
        {
           return _context.Examinations.ToList();
        }

        public Examinations GetExamById(string eId)
        {
            Examinations exam = _context.Examinations.Find(eId);
            return exam;
        }

        public void Update(Examinations examinations)
        {
            _context.Examinations.Update(examinations);
            _context.SaveChanges();
        }
    }
}
